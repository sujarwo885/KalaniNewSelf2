Reference
=========

.. contents::
    :local:
    :backlinks: none

Subpackages
-----------

.. toctree::

    urllib3.contrib
    urllib3.util

Submodules
----------

urllib3.connection module
-------------------------

.. automodule:: urllib3.connection
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.connectionpool module
-----------------------------

.. automodule:: urllib3.connectionpool
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.exceptions module
-------------------------

.. automodule:: urllib3.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.fields module
---------------------

.. automodule:: urllib3.fields
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.filepost module
-----------------------

.. automodule:: urllib3.filepost
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.poolmanager module
--------------------------

.. automodule:: urllib3.poolmanager
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.request module
----------------------

.. automodule:: urllib3.request
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.response module
-----------------------

.. automodule:: urllib3.response
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: urllib3
    :members:
    :undoc-members:
    :show-inheritance:

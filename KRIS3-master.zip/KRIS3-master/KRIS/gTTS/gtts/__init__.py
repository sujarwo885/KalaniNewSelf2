from .version import __version__
from .tts import gTTS

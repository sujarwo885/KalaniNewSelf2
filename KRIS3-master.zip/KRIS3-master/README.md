Bot versi KRIS

sudo apt-get update
sudo apt-get install python-software-properties
sudo apt-get install git
sudo apt-get install dict
sudo pip install rsa
sudo pip install requests
sudo pip install thrift==0.9.3
sudo pip install goslate
sudo pip install gTTS
sudo pip install tts
sudo pip install bs4
sudo pip install beautifulsoup
sudo pip install tweepy
sudo pip install urllib3
sudo pip install wikipedia

